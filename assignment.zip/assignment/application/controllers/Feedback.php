<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feedback extends CI_controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('Database_model');
			
				}

	public function index()
	{
		$data=array();
		$data['title']="Algofocus";
		$this->load->view('header',$data);
		$this->load->view('nav');
		$this->load->view('feedback');
		$this->load->view('footer');
	}
	
	public function sub_cmnt(){
		//$autoload['model'] = array('Database_model'=>'');
		if($this->input->post('comment')!==NULL)
		{ 
		$data['name']=$this->input->post('name');
		$data['email']=$this->input->post('email');
		$data['phone']=$this->input->post('phone');
		$data['dob']=$this->input->post('dob');
		$data['age']=$this->input->post('age');
		$this->load->model('Database_model');
		$run=$this->Database_model->insertbyarray("comment",$data);
		if($run==true){
			$name=$this->input->post('name');
			$where="`name`='$name'";
			$getname=$this->Database_model->getlastdata("comment",$where);
			echo $cname=$getname['name'];
			$msg="<div class='alert alert-success'><strong> Thank you '$cname' Your Comment Added Sucessfully  </strong></div>";
					$arr=array("msg"=>$msg);
					$this->session->set_flashdata($arr);
					redirect("/feedback/fetch");
			}
		
			}		
			
	} /* End of Comment */
	public function fetch(){
		$data=array();
		$data['title']="Algofocus";
		$table="comment";
		$where="1";
		$array=$this->Database_model->getrows($table,$where);
		$data['array']=$array;
		$this->load->view('header',$data);
		$this->load->view('nav');
		$this->load->view('feedback');
		$this->load->view('view_feed',$data);
		$this->load->view('footer');
		
	
	}
}
