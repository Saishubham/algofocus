<div class="table-responsive" style="margin-top:20px;">
                    <table class="table table-bordered">
                        <thead>
                        
							<tr>
                                <th>name</th>
                                <th>email</th>
                                <th>Date of birth</th>
                                   <th>Age</th>
                                 <th>Contact</th>
                                 </tr>
                        </thead>
                        <tbody>
                        <?php
						
                        foreach($array as $rec){
							
                            ?>
                            <tr>
                                <td><?php echo $rec['name'];?> </td>
                                <td><?php echo $rec['email'];?></td>
                                <td><?php  echo $rec['dob'];?></td>
                                <td><?php  echo $rec['age'];?></td>
                                 <td><?php  echo $rec['phone'];?></td>
                                
                            </tr>
                          <?php 
						  
						   }  ?>
                        
                        </tbody>
                    </table>
                  </div>  