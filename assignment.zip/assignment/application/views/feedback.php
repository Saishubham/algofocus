<div class="text-center text-success"><?php echo $this->session->flashdata('msg'); ?></div>

<div class="container">

<div class="col-md-4">

</div>
<div class="col-md-4">
<h3>Form</h3>
<form action="<?php echo base_url(); ?>index.php/feedback/sub_cmnt/" method="post"  class="form-horizontal" name="myForm" onsubmitdd="return validate_len()">

	<div>
	<label>Name:</label>
		<input type="text" name="name" class="form-control" placeholder="Enter Yoour name" onKeyPress="return ValidateAlpha(event);" required>
	</div>
 <div>
    <label>Date of Birth</label>
 	<input type="date" name="dob"  id="dob" placeholder="mm/dd/yyyyy" class="form-control" required>
    </div>
     <div>
    <label>Age</label>
 	<input type="text" name="age"  id="age" onFocus="getage()" class="form-control" placeholder="click me for age" readonly>
    </div>
        <div>
    <label>Email</label>
    <input type="email" name="email" placeholder="enter your email" class="form-control" required>
    
    </div>
    <div>
    <label>Phone</label>
    <input type="text" name="phone" placeholder="enter phone number" class="form-control" onkeypress="return isNumberKey(event)"   required>
    </div>
    <div class=" text-right" style="margin-top:5px;">
                        	<center><button type="submit" class="btn btn-warning btn-lg" id="submitbtn" name="comment" >Send <span class="glyphicon glyphicon-send"></span></button></center>
                        </div> 

</form>
</div>
<div class="col-md-4"></div>



</div>
