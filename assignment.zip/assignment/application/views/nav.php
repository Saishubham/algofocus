<div class="bgh">
<nav class="navbar">
 <a class="navbar-brand" style="margin-left:10px; size:30px; size:40px;" href="<?php  echo base_url();?>"><strong>Algofocus Technology</strong></a>
      <div class="container-fluid">
      
        <div class="navbar-header menu">
          <button type="button btn-danger"  class="navbar-toggle collapsed" data-toggle="collapse" aria-expanded="false" data-target="#site-menu">
          <span><a href="#">Menu</a></span>
          </button>
           </div>
           
        <!-- end of navbar-header-->
        
        <div class="collapse navbar-collapse" id="site-menu">
          <ul class="nav navbar-nav navbar-left" style="padding-top:50px;">
          <?php
				  	
							if($this->session->userdata('user_id')!==NULL){
				  ?>
           
            <li class="active <?php echo set_active("feedback/fetch/"); ?>"><a href="<?php echo base_url(); ?>index.php/feedback/fetch/"><span class="glyphicon glyphicon-user"><strong>TASK</strong></span></a></li>
           
           <li class=" <?php echo set_active("login/logout"); ?>"><a href="<?php echo base_url();?>index.php/login/logout/"><span class="glyphicon glyphicon-log-out"><strong>logout</strong></span></a></li> 
         
           
 

         
         <?php 
							}
		 ?>  
           </ul>
        </div>
      </div>
    </nav>
    </div>