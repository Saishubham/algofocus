<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/bootstrap/css/bootstrap.css">
       <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/bootstrap/css/bootstrap-theme.min.css">
       <link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/style.css">
       <script type="text/javascript" src="<?php echo base_url(); ?>Assets/bootstrap/js/jquery.min.js"></script>
         <script type="text/javascript" src="<?php echo base_url(); ?>Assets/bootstrap/js/bootstrap.min.js"></script>
         

  <script>
        
function isNumberKey(evt){  <!--Function to accept only numeric values-->
    //var e = evt || window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31 
	&& (charCode < 48 || charCode > 57))
        return false;
        return true;
	}
		   
    function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }
function myform(){
	alert("Sure ! your data is being submited successfully");
}
</script>
<script>
	
	$('#dob,#age').on('keyup',getage);
    
	function getage(){
		var today = new Date();
		var n = today.getFullYear();
		var dob = new Date($('#dob').val());
		var d=dob.getFullYear();
		var age=n-d;
		$('#age').val(age);
		if(age=='NaN'||age<18){
		alert("oops..your age is"+age+" less than 18");
		document.getElementById("submitbtn").style.display = "none";
		return false;
		}
		else{
			confirm("confirm? your age is "+age+"");
			document.getElementById("submitbtn").style.display ="block";
			return true;
			}
			
		
		
		}
  

  </script>
        

        <title>Algofocus tech| <?php echo $title; ?></title>
        
    </head>
    <body class="">
   